دفتر الجزار - مشروع أندرويد

مهم: هذا مشروع مصدر Android Studio، وليس ملف APK جاهزًا. يجب بناء APK باستخدام Android Studio على كمبيوتر.

طريقة بناء APK:
1) نزّل وثبّت Android Studio من الموقع الرسمي:
   https://developer.android.com/studio
2) فك ضغط ملف ZIP.
3) افتح Android Studio واختر Open، ثم اختر مجلد DaftarAlJazzar (المجلد الذي يحتوي settings.gradle).
4) انتظر انتهاء Gradle Sync، ووافق على تثبيت مكونات Android SDK إذا طلب ذلك.
5) من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) بعد انتهاء البناء، اضغط Locate في إشعار النجاح. غالبًا ستجد الملف هنا:
   app/build/outputs/apk/debug/app-debug.apk
7) انقل app-debug.apk إلى هاتف أندرويد، وافتحه. إذا طُلب ذلك، اسمح بتثبيت التطبيقات من هذا المصدر.

التطبيق يعمل محليًا ولا يحتاج إلى إنترنت لتشغيل صفحة الحساب.
سجل الأيام يُحفظ محليًا داخل بيانات WebView لهذا التطبيق؛ لا تمسح بيانات التطبيق إذا أردت الاحتفاظ بالسجل.
احتفظ بنسخة احتياطية من بياناتك المهمة؛ هذا الإصدار لا يحتوي على تصدير أو مزامنة سحابية.

ملاحظة: إذا ظهر خطأ Gradle/SDK، تأكد من أن Android Studio يستطيع تنزيل مكونات البناء، ثم جرّب Sync Project with Gradle Files.
مرجع رسمي لتحميل HTML محليًا داخل تطبيق أندرويد:
https://developer.android.com/develop/ui/views/layout/webapps/load-local-content
